package com.TrainTicket.trainTicket.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.TrainTicket.trainTicket.model.Registration;

public interface RegRep extends JpaRepository<Registration,String> {
	public Registration findByEmail(String em);

}
